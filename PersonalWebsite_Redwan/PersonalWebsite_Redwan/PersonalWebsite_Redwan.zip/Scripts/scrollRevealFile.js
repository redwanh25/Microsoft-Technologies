﻿const sr = ScrollReveal();

sr.reveal('#About', {
    origin: 'bottom',
    duration: 1000,
    distance: '150px'
});

sr.reveal('#CV', {
    origin: 'bottom',
    duration: 1000,
    distance: '150px'
});

sr.reveal('#Education', {
    origin: 'bottom',
    duration: 1000,
    distance: '150px'
});

sr.reveal('#Services', {
    origin: 'bottom',
    duration: 1000,
    distance: '150px'
});

sr.reveal('#Experiences', {
    origin: 'bottom',
    duration: 1000,
    distance: '150px'
});

sr.reveal('#Skills', {
    origin: 'bottom',
    duration: 1000,
    distance: '150px'
});

sr.reveal('#bg-image2', {
    origin: 'bottom',
    duration: 1000,
    distance: '150px'
});

sr.reveal('#apsc2', {
    origin: 'bottom',
    duration: 1000,
    distance: '150px'
});

sr.reveal('#apsc1', {
    origin: 'bottom',
    duration: 1000,
    distance: '150px'
});

sr.reveal('#Projects', {
    origin: 'bottom',
    duration: 1000,
    distance: '150px'
});

sr.reveal('#Contact', {
    origin: 'bottom',
    duration: 1000,
    distance: '150px'
});