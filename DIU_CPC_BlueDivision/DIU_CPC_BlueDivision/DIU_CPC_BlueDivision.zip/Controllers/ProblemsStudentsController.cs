﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DIU_CPC_BlueDivision.DatabaseConnection;
using DIU_CPC_BlueDivision.DifferentLayout_Database;
using DIU_CPC_BlueDivision.Models;
using Microsoft.AspNet.Identity;

namespace DIU_CPC_BlueDivision.Controllers
{
    public class ProblemsStudentsController : Controller
    {
        private BlueSheetsProblemsStudentsEntities db = new BlueSheetsProblemsStudentsEntities();

        // GET: ProblemsStudents
        [NonAction]
        public ActionResult Index()
        {
            var problemsStudents = db.ProblemsStudents.Include(p => p.Problem).Include(p => p.Student);
            return View(problemsStudents.ToList());
        }

        // GET: ProblemsStudents/Details/5
        [NonAction]
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ProblemsStudent problemsStudent = db.ProblemsStudents.Find(id);
            if (problemsStudent == null)
            {
                return HttpNotFound();
            }
            return View(problemsStudent);
        }

        // GET: ProblemsStudents/Create
        public ActionResult Create(int problemId, string userName)
        {
            //ViewBag.ProblemId = new SelectList(db.Problems, "Id", "ProblemName");
            //ViewBag.StudentId = new SelectList(db.Students, "Id", "UserName");

            List<ProblemsStudent> problemsStudents = db.ProblemsStudents.Where(per => per.ProblemId == problemId && per.Student.UserName == userName).ToList();
            if (problemsStudents.Count != 0)
            {
                throw new Exception();
            }

            string U_id = "", str = "", joinSemester = "", userName1 = "";
            U_id = User.Identity.GetUserId();

            if (!string.IsNullOrEmpty(U_id))
            {
                AspNetUsersBusinessLayer aspNetUsersBusinessLayer = new AspNetUsersBusinessLayer();
                str = aspNetUsersBusinessLayer.GetSecureCode(U_id);
                joinSemester = aspNetUsersBusinessLayer.GetJoinSemester(U_id);
                userName1 = aspNetUsersBusinessLayer.GetUserName(U_id);
            }
            if (str != "1234_U1")
            {
                if (userName1 == userName)
                {
                    List<Problem> problem = db.Problems.Where(per => per.BlueSheet.BlueSheetName == joinSemester).ToList();
                    foreach (Problem p in problem)
                    {
                        if (p.Id == problemId)
                        {
                            //ViewBag.ProblemId = new SelectList(db.Problems.Where(per => per.Id == problemId), "Id", "ProblemName");
                            //ViewBag.StudentId = new SelectList(db.Students.Where(per => per.UserName == userName), "Id", "UserName");
                            return View();
                        }
                    }
                    throw new Exception();
                }
                else
                {
                    throw new Exception();
                }
            }
            else
            {
                throw new Exception();
            }

        }

        // POST: ProblemsStudents/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Comment,IsSolved,SolutionLink,ShareSolutionLink")] ProblemsStudent problemsStudent)
        {
            string userId = "", joinSem = "";
            userId = User.Identity.GetUserId();

            if (!string.IsNullOrEmpty(userId))
            {
                AspNetUsersBusinessLayer aspNetUsersBusinessLayer = new AspNetUsersBusinessLayer();
                joinSem = aspNetUsersBusinessLayer.GetJoinSemester(userId);
            }

            string U_id = "", str = "", joinSemester = "", userName1 = "";
            U_id = User.Identity.GetUserId();

            if (!string.IsNullOrEmpty(U_id))
            {
                AspNetUsersBusinessLayer aspNetUsersBusinessLayer = new AspNetUsersBusinessLayer();
                str = aspNetUsersBusinessLayer.GetSecureCode(U_id);
                joinSemester = aspNetUsersBusinessLayer.GetJoinSemester(U_id);
                userName1 = aspNetUsersBusinessLayer.GetUserName(U_id);
            }
            List<Problem> problem = db.Problems.Where(per => per.BlueSheet.BlueSheetName == joinSemester).ToList();

            string appPath = "";
            appPath = string.Format("{0}", Request.Url.AbsoluteUri);
            string[] arr = appPath.Split('=');
            string arr1 = arr[1];
            string[] arr2 = arr1.Split('&');
            int probId = Convert.ToInt32(arr2[0]);

            problemsStudent.ProblemId = probId;
            problemsStudent.StudentId = userId;
            if (ModelState.IsValid)
            {
                db.ProblemsStudents.Add(problemsStudent);
                db.SaveChanges();
                return RedirectToAction("Index", "Problems", new { id_Or_SheetName = joinSem });
            }

            ViewBag.ProblemId = new SelectList(db.Problems, "Id", "ProblemName", problemsStudent.ProblemId);
            //ViewBag.StudentId = new SelectList(db.Students, "Id", "UserName", problemsStudent.StudentId);
            return View(problemsStudent);
        }

        // GET: ProblemsStudents/Edit/5
        public ActionResult Edit(int problemId, string userName)
        {
            string U_id = "", str = "", joinSemester = "", userName1 = "";
            U_id = User.Identity.GetUserId();

            if (!string.IsNullOrEmpty(U_id))
            {
                AspNetUsersBusinessLayer aspNetUsersBusinessLayer = new AspNetUsersBusinessLayer();
                str = aspNetUsersBusinessLayer.GetSecureCode(U_id);
                joinSemester = aspNetUsersBusinessLayer.GetJoinSemester(U_id);
                userName1 = aspNetUsersBusinessLayer.GetUserName(U_id);
            }
            if (str != "1234_U1")
            {
                if (userName1 == userName)
                {
                    List<Problem> problem = db.Problems.Where(per => per.BlueSheet.BlueSheetName == joinSemester).ToList();
                    foreach (Problem p in problem)
                    {
                        if (p.Id == problemId)
                        {
                            if (db.ProblemsStudents.FirstOrDefault(per => per.Problem.Id == problemId && per.Student.UserName == userName) == null)
                            {
                                return RedirectToAction("Create", "ProblemsStudents", new { problemId, userName });
                                //return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                            }
                            ProblemsStudent problemsStudent = db.ProblemsStudents.FirstOrDefault(per => per.Problem.Id == problemId && per.Student.UserName == userName);
                            if (problemsStudent == null)
                            {
                                return HttpNotFound();
                            }
                            ViewBag.ProblemId = new SelectList(db.Problems.Where(per => per.Id == problemId), "Id", "ProblemName", problemsStudent.ProblemId);
                            ViewBag.StudentId = new SelectList(db.Students.Where(per => per.UserName == userName), "Id", "UserName", problemsStudent.StudentId);
                            return View(problemsStudent);
                        }
                    }
                    throw new Exception();
                }
                else
                {
                    throw new Exception();
                }
            }
            else
            {
                throw new Exception();
            }
        }

        // POST: ProblemsStudents/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Comment,IsSolved,SolutionLink,ShareSolutionLink,ProblemId,StudentId")] ProblemsStudent problemsStudent)
        {
            string userId = "", joinSem = "";
            userId = User.Identity.GetUserId();

            if (!string.IsNullOrEmpty(userId))
            {
                AspNetUsersBusinessLayer aspNetUsersBusinessLayer = new AspNetUsersBusinessLayer();
                joinSem = aspNetUsersBusinessLayer.GetJoinSemester(userId);
            }
            if (ModelState.IsValid)
            {
                db.Entry(problemsStudent).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index", "Problems", new { id_Or_SheetName = joinSem });
            }
            ViewBag.ProblemId = new SelectList(db.Problems, "Id", "ProblemName", problemsStudent.ProblemId);
            ViewBag.StudentId = new SelectList(db.Students, "Id", "UserName", problemsStudent.StudentId);
            return View(problemsStudent);
        }

        // GET: ProblemsStudents/Delete/5
        [NonAction]
        public ActionResult Delete(int? problemId, string studentId)
        {
            if (problemId == null && studentId == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ProblemsStudent problemsStudent = db.ProblemsStudents.FirstOrDefault(per => per.ProblemId == problemId && per.StudentId == studentId);
            if (problemsStudent == null)
            {
                return HttpNotFound();
            }
            return View(problemsStudent);
        }

        // POST: ProblemsStudents/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [NonAction]
        public ActionResult DeleteConfirmed(int? problemId, string studentId)
        {
            ProblemsStudent problemsStudent = db.ProblemsStudents.FirstOrDefault(per => per.ProblemId == problemId && per.StudentId == studentId);
            db.ProblemsStudents.Remove(problemsStudent);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Solver(int problemId)
        {
            //int problemCount = db.ProblemsStudents.Where(per => per.ProblemId == problemId && per.IsSolved == "Accepted").ToList().Count;
            //ProblemsClass pc = new ProblemsClass();
            //pc.updateProblemSolverCount(problemId, problemCount);

            string U_id = "", str = "", joinSemester = "";
            U_id = User.Identity.GetUserId();

            if (!string.IsNullOrEmpty(U_id))
            {
                AspNetUsersBusinessLayer aspNetUsersBusinessLayer = new AspNetUsersBusinessLayer();
                str = aspNetUsersBusinessLayer.GetSecureCode(U_id);
                joinSemester = aspNetUsersBusinessLayer.GetJoinSemester(U_id);
            }
            if (str != "1234_U1")
            {
                List<Problem> problem = db.Problems.Where(per => per.BlueSheet.BlueSheetName == joinSemester).ToList();
                foreach (Problem p in problem)
                {
                    if (p.Id == problemId)
                    {
                        List<ProblemsStudent> problemsStudents = db.ProblemsStudents.Where(per => per.ProblemId == problemId).ToList();   //&& per.IsSolved == "Accepted"
                        return View(problemsStudents);
                    }
                }
                throw new Exception();
            }
            else
            {
                List<ProblemsStudent> problemsStudents = db.ProblemsStudents.Where(per => per.ProblemId == problemId).ToList();   //&& per.IsSolved == "Accepted"
                return View(problemsStudents);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
